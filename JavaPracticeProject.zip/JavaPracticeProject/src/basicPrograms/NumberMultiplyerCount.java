package basicPrograms;
public class NumberMultiplyerCount {

	void m1() {

		System.out.println("Number" + " " + "Multiplier" + " " + "Output");
		for (int i = 1; i <= 5; i++) {
			for (int j = 1; j <= 10; j++) {
				System.out.println(i + "     " + "*" + "    " + j + " " + "     " + "=" + "   " + (i * j));
			}
			System.out.println("------------------------------------");
		}
	}

	public static void main(String[] args) {
		NumberMultiplyerCount Tb = new NumberMultiplyerCount();
		Tb.m1();
	}

}