package asciiValue;

public class PrintAsciiValueOfCharGivenRange {
	
	
	void printChar(int startRange, int endRange) {
		
		for(int i=startRange;i<=endRange;i++) {
			
			char ch=(char) i;
			System.out.println("Character at " +i +" is= " +ch);
			
		}
	}

	public static void main(String[] args) {
		PrintAsciiValueOfCharGivenRange assignment28=new PrintAsciiValueOfCharGivenRange();
		assignment28.printChar(65, 100);
	}

}
