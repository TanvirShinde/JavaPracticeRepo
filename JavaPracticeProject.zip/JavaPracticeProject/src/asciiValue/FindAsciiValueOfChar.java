package asciiValue;

public class FindAsciiValueOfChar {
	
	void findcharfromAscii(int input) {
		
		char ch=(char) input;
		System.out.println("Character for Given Ascii Values are = "+ch);
		
	}

	public static void main(String[] args) {
		FindAsciiValueOfChar assignment27=new FindAsciiValueOfChar();
		assignment27.findcharfromAscii(65);
		assignment27.findcharfromAscii(90);
		assignment27.findcharfromAscii(55);
	}

}
